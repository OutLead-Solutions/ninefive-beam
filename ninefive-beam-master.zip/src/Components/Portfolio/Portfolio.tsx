import React from "react";
import { Footer } from "../Footer/Footer";
import { Header } from "../Header/Header";
import { WhatsApp } from "@mui/icons-material";
import { IconButton, Link as MaterialLink } from "@mui/material";
import img1 from "../../Assets/Images/Core Values/integrity.png";

const Portfolio = () => {
  return (
    <>
      <div className="container-fluid portfolio-container p-0">
        <Header />
        <div
          className="container img-container mt-5 mb-5"
          data-aos="zoom-in"
          data-aos-delay={700}
        >
          <h1 className="text-bold text-center">NineFive BIM Portfolio</h1>
          <h3 className="text-center">
            We have done projects across residential, commercial, industrial,
            institutional and other segments.
          </h3>
        </div>

        <div className="container text-center mt-5 mb-5">
          <button type="button" className=" m-2 btn btn-outline-secondary">
            ALL
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            ARTS AND ENTERTAINMENT
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            COMMERCIAL
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            HEALTHCARE
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            HERITAGE
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            HOSPITALITY
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            INDUSTRIAL
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            INFRASTRUCTURAL
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            INSTITUTIONAL
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            MIXED USE DEVELOPMENT
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            PUBLIC WORK
          </button>
          <button type="button" className=" m-2 btn btn-outline-secondary">
            RESIDENTIAL
          </button>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
          </div>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
          </div>
        </div>
        <div className="container">
          <div className="row">
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
            <div className="col-md-4 p-2">
              <img
                src={img1}
                alt="img-1"
                style={{ width: "500px", height: "500px" }}
              />
            </div>
          </div>
        </div>
      </div>
      {/* 
      <div className="container-fluid mt-5 mb-5">
   
      </div> */}
      <MaterialLink href="https://wa.me/7016591928" target="_blank">
        <IconButton
          size="large"
          className="bg-dark text-success"
          style={{ position: "fixed", bottom: 45, right: 40 }}
        >
          <WhatsApp />
        </IconButton>
      </MaterialLink>
      <Footer />
    </>
  );
};

export default Portfolio;
