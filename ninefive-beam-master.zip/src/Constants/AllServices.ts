export const AllServiceList = [
  {
    name: "BIM Modelling LOD 300/400/500",
    link: "/sub-service/2/3D Bim Services",
  },
  {
    name: "4D/5D Simulation",
    link: "/sub-service/2/4D Bim Services",
  },
  {
    name: "BIM Consulting",
    link: "/bim",
  },
  {
    name: "CAD Services",
    link: "/sub-service/2/Laser CAD Services",
  },
  {
    name: "BIM for Infrastructure",
    link: "#",
  },
  {
    name: "Quantity Estimation",
    link: "#",
  },
  {
    name: "Project Management Tracking",
    link: "#",
  },
  {
    name: "Steel Design & Engineering",
    link: "#",
  },
  {
    name: "Clash Detection and Constructability Analysis",
    link: "/sub-service/2/Coordination & Clash Detection Services",
  },
  {
    name: "BIM to FM",
    link: "#",
  },
];
