export const coreValues = [
    {
        name:'Accountability',
        description:'Each of us is responsible for our words, our actions, and our results.',
    },
    {
        name:'Respect',
        description:'We value everyone and treat people with dignity and professionalism.',
    },
    {
        name:'Integrity',
        description:'We build trust through responsible actions and honest relationships.',
    },
    {
        name:'Teamwork',
        description:'We achieve more when we collaborate and all work together.',
    },
]