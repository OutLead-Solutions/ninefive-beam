export const Expertise = [
    {
        name: 'BIM Implementation Advisory',
        description: "Be on the right track from Day 0 with a well-constructed enterprise BIM roadmap & standards. Construct and standardize BIM workflow through the direct transfer of Virtual Building Studio's extensive knowledge and experience."
    },
    {
        name: 'BIM Training & Handholding',
        description: "Award-winning 3D BIM Modeling, 4D BIM Simulation, 5D BIM quantity takeoff & project finance management and 7D BIM facility management service."
    },
    {
        name: 'Project-Based Training',
        description: "Train according to your need. Speed up the establishment of your own BIM team with hands-on courses specially designed based on your unique project.Train according to your need. Speed up the establishment of your own BIM team with hands-on courses specially designed based on your unique project."
    },
]